#' ---
#' title: TD1 - Analyse des données
#' author: Nicolas Jouvin / Chargé de cours -> M. Joseph Rynkiewiscz
#' output: html_notebook
#' ---
#' 
#' # Premier TD/TP d'analyse de donnée
#' 
#' <!-- ```{r} -->
#' <!-- install.packages('knitr') -->
#' <!-- ``` -->
#' 
#' 
#' <!-- ```{r , include=F} -->
#' <!-- library(knitr) -->
#' <!-- knitr::opts_chunk$set(collapse=TRUE, fig.width=6, fig.height=6) -->
#' <!-- ``` -->
#' 
#' 
#' 
## ------------------------------------------------------------------------
x = 2
x

#' 
#' # Connaitre son environnement de travail (là où R va lire et enregistrer les fichiers par défaut)
#' Pour trouver le répertoire de travail
## ------------------------------------------------------------------------
getwd()

#' 
#' Pour le changer 
## ------------------------------------------------------------------------
# Chemin à fixer selon sa machine : setwd('chemin/absolu/ou/relatif/')

#' Si on veut fixer le "working directory" au même endroit où est enregistrer notre fichier `.R` il existe un raccourci dans Rstudio : Seesion -> Set Working directory -> To source file location
#' 
#' # création de deux vecteurs
## ------------------------------------------------------------------------
weight  = c(60, 72, 57, 90, 95, 72)
height = c(1.75, 1.80, 1.65, 1.90, 1.74, 1.91)

#' 
#' 
## ------------------------------------------------------------------------
length(height)

#' 
#' Opérations sur les vecteurs :
## ------------------------------------------------------------------------
height^2

#' 
#' 
## ------------------------------------------------------------------------
bmi = weight / height^2
print(paste('BMI de l\'individu 1 :', bmi[1]))
print(paste('BMI de l\'individu 2 :', bmi[2]))

#' 
#' 
## ------------------------------------------------------------------------
moyenne_r = mean(bmi)
moyenne_r
moyenne_math =sum(bmi)/length(bmi)
moyenne_math

print(moyenne_math == moyenne_math)

var_r = var(bmi)
var_r
var_math = sum((bmi - mean(bmi))^2)/(length(bmi)-1)
var_math
print(var_r == var_math)

#' 
#' # matrice
#' 
#' 
## ------------------------------------------------------------------------
A = matrix(c(1, 2, 7, 9), 2, 2, byrow = T)
A[1, 1]
A
A[1, 2] = 19
A

#' 
#' 
#' 
#' 
#' 
#' # tableau individus-variables = data frame
## ----creation data-frame-------------------------------------------------
X = data.frame(weight, height)
print(X)

#' 
#' On selectionne les colonnes par leur noms avec l'opérateur $ comme suit : 
## ----selection de colonne par nom de variable----------------------------
print(X$weight)
print(all.equal(X$weight, weight))

#' 
#' Les data-frame s'indexent aussi comme des matrices !
## ----indexation matricielle pour les dfs---------------------------------
print(all.equal(X$height, X[,2]))

#' 
#' 
#' Modifier le vecteur `weight` ne modifie pas `X$weight`.
## ------------------------------------------------------------------------
weight[2] = 0
print(all.equal(X$weight, weight))

#' 
#' 
#' # Indexation booléenne
#' On peut selectionner des lignes avec des conditions (vecteur de booleens).
## ----selection conditionelle---------------------------------------------
bool = X$height <= 1.80
print(bool)
print(X[bool,]) # renvoi les individus de X vérifiant la condition `bool`
print(which(bool)) # renvoi les indices tq bool == TRUE

#' Somme de booleen TRUE ==1 et FALSE == 0. Pratique pour compter les individus respectant une certaine condition
#' 
## ------------------------------------------------------------------------
sum(X$weight <= 90) 

#' 
#' On peut selectionner plusieurs lignes en passant un vecteur d'indices comme suit :
## ------------------------------------------------------------------------
height[c(1,3)]

#' 
#' 
#' En combinant ce que l'on vient d'apprendre, on voit que l'on peut donc faire des opérations sur des sous-vecteurs selectionnés selon certaines conditions (ici la moyenne des poids des individus mesurant moins de 1.80)
## ------------------------------------------------------------------------
sum(X$weight[bool] / length(X$weight[bool]))
#ou plus court :
mean(X$weight[bool])

#' 
## ------------------------------------------------------------------------
sum(height < 1.75)

sum(weight > 70)/length(weight)

sum( height < 1.75 & weight >= 60 )

#' 
#' 
#' # Graphiques
## ------------------------------------------------------------------------
plot(height, weight, col="red", pch=6)


#' 
#' 
#' 
## ------------------------------------------------------------------------
bmi <- weight / height^2
n=length(bmi)
prop <- c(sum(bmi<20)/n, sum(bmi>=20&bmi<25)/n, sum(bmi>=25)/n) 
names(prop) <- c("Anorexique","Normal","Obèse")
pie(prop)

#' 
#' 
#' 
#' # Enregistrement des données (pour reprodutibilité et/ou calculs lourds)
#' 
#' Sauvegardez votre data-frame à l'aide de la fonction `write.table`
## ------------------------------------------------------------------------
write.table(X, file="dat.txt", col.names = F, row.names = F)

#' 
#' Et pui rechargez vos données ensuite (ou envoyer les à vos collègues qui pourront les chargez) avec :
## ------------------------------------------------------------------------
Y = read.table(file="dat.txt")
colnames(Y) = c("weight", "height")

#' 
#' 
#' 
#' 
#' 
#' # RData : 
#' On a sauvegardé le fichier dans un fichier .txt mais il existe un format spécifique à R : le format .Rdata. 
#' 
#' * Pros : Il est adapté aux différents types de donnée R et est plus compact 
#' * Cons: Spécifique à R / Difficile lorsque l'on travail avec plusieurs language (e.g. R + Python)
## ------------------------------------------------------------------------
save(X, file="dat.RData") # save.image(file="dat.RData") sauvegarde tout le workspace

rm(list=ls()) # retire tous les objet du workspace (environnement global)
load(file="dat.RData") # pour recharger les données

#' 
#' 
#' 
#' 
#' 
#' 
#' 
#' 
