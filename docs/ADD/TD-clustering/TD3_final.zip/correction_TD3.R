#' ---
#' title: TD3 - Analyse des données
#' author: Nicolas Jouvin / Chargé de cours -> M. Joseph Rynkiewiscz
#' output: html_notebook
#' ---
## ------------------------------------------------------------------------
library(dplyr)
library(ggplot2)

#' 
#' On créé les données
## ----creation-donnees----------------------------------------------------
var1 <- c(-3.3, -4.4, -1.9, 3.3, 2.5, 3.2, 0.3, 0.1, -0.1, -0.5)
groupe <- c(1, 1, 1, 2, 2, 2, 2, 3, 3, 3)

#' 
#' 
#' # Séance 1 : CAH
#' 
#' Pour automatiser les choses dans ce TP, on créé une fonction pour calculer $S$, $B$ et renvoyer le rapport $S/B$ d'une partition quelconque des observations.
#' 
## ----comppute S sur B, echo=T--------------------------------------------
compute_criterion = function(var1, groupe){
  
  n = length(var1)
  S = ((n - 1)/n) * var(var1)
  
  xbark = c()
  for (i in unique(groupe)) { 
    xbark = c(xbark, mean(var1[groupe == i]))
  }
  moyenne = mean(var1)
  
  m = table(groupe) # cptage du nbre d'individus dans chaque cluster
  B = sum(m*((xbark - moyenne)/sqrt(n))^2)
  
  if (B == 0) 
    warning('B=0 : partition à un seul cluster.')
  
  
  return(S/B)
}

#' 
#' On peut illustrer la fonction avec le code suivant :
## ------------------------------------------------------------------------
groupe <- c(1, 1, 1, 2, 2, 2, 2, 3, 3, 3)
crit = compute_criterion(var1 = var1, groupe = groupe)
cat('Rapport S/B pour cette partition des données : ', crit, '. \n') 

# new partition
groupe = c(1, 1, 1, 2, 2, 2, 3, 3, 3, 3)

crit = compute_criterion(var1 = var1, groupe = groupe)
cat('Rapport S/B pour la nouvelle partition des données : ', crit, '. \n') 


#' 
#' La fonction `hclust` implémente la CAH dans R. On peut jouer sur l'argument `method` pour utiliser différente distances ensemblistes.
#' 
#' ### CAH : lien mininum ou `single` link
## ------------------------------------------------------------------------
library(cluster)
# 1. Exemple avec maximum likage
method = "single" # methode du lien maximum
cah = hclust(dist(var1), method = method)
plot(cah)

#' 
#' On peut afficher la valeur de $S/B$ le long du dendrogramme (hiérarchie de partition emboîtée) :
## ----echo=F--------------------------------------------------------------
n = length(var1)
crit = rep(0, n-1)
for (k in 2:n) {
  partition = cutree(cah, k = k)
  crit[k-1] = compute_criterion(var1 = var1, groupe = partition)
}

dfplot = data.frame(K = 2:n, crit = crit)
plot(dfplot, ylab = 'S/B')
lines(2:n, crit)

#' 
#' Ou plus de manière plus jolie visuellement avec la librarie ggplot2 :
## ----echo=F--------------------------------------------------------------
gg = ggplot(dfplot) + geom_point(aes(x=K, y=crit)) + 
  geom_line(aes(x=K, y=crit)) +
  scale_x_continuous(breaks=2:n) +
  scale_y_continuous(name = 'S/B') 
print(gg)

#' 
#' Lorsque K augmente le rapport $S/B$ à tendance à décroitre jusqu'à son minimum trivial, la partition à $K=N$ où chaque point est dans son cluster (alors $B=S \implies S/B=1$). Ce graphique s'interprète comme le gain marginal de chaque fusion dans la hiérarchie. Il permet donc de quantifier le "gain" en $B$ qu'apporte le passage du niveau $K$ à $K+1$ clusters. On voit que les première fusions apportent beaucoup mais que l'utilité marginale des fusions, décroit fortement à partir de $K=3$. On choisit donc de manière **heuristique** $K^\star = 3$ : c'est la *elbow rule*. Dans ce cas simple le coude est très prononcé mais dans des cas plus compliqué le graphe peut vite devenir visuellement confus : présence de plusieurs coude, etc. La décision se fait alors au cas par cas, en tenant compte du problème à traiter (limite sur le nombre de groupe, analyse qualitative du résultats). C'est la force et la faiblesse de la CAH car il y a très peu d'hypothèses faite sur la nature des données. On verra avec les mélanges gaussiens que lorsque des hypothèses de nature statistique sont faites sur les données, on peut construire des critères de séléction de modèle (AIC, BIC, ICL).
#' 
#' # Séance 2 : K-means
#'  
#' Pour faire tourner le kmeans à la main dans $\mathbb{R}$ il peut-être utile de dessiner les points de manière ordonnées comme ceci :
## ---- echo=F-------------------------------------------------------------
# affichage des points
df = data.frame(x=sort(var1), y=0, label=order(var1))
ggplot(df, aes(x=x, y=y, label=label)) + geom_point() + geom_text(aes(label=order(var1)), vjust=2)


#' La fonction `kmeans` implémente l'algorithme des K-means dans R. L'initilisation se fait grâce à l'argument `centers`.
#' 
#' ### K=2
#' Initialisation : \[ \mu_1^{(0)} = x_1, \quad \mu_2^{(0)} = x_{10}\]
## ----echo=T, include=T---------------------------------------------------
k_moyennes = kmeans(var1, centers = c(var1[1], var1[10]))
cat('Les centres finaux trouvés sont :' , k_moyennes$centers, '\n')
cat('Le rapport S/B associé à la partition (', k_moyennes$cluster , ') est : ', k_moyennes$totss / k_moyennes$betweenss, '\n')

## ----echo=F--------------------------------------------------------------
groupe = factor(k_moyennes$cluster)
ggplot(data = data.frame(var1), aes(x=var1, y=NA, color=groupe)) + geom_point()


#' 
#' ### K=3
#' Initialisation : \[ \mu_1^{(0)} = x_1, \quad \mu_2^{(0)} = x_{5}, \quad \mu_3^{(0)} = x_{10}\]
## ----echo=F--------------------------------------------------------------
k_moyennes = kmeans(var1, centers = c(var1[1], var1[5], var1[10]))
cat('Le Kmeans à convergé en ', k_moyennes$iter,' itérations. \n')
cat('Le rapport S/B associé à ', k_moyennes$cluster , ' est : ', k_moyennes$totss / k_moyennes$betweenss, '\n')
groupe = factor(k_moyennes$cluster)
ggplot(data = data.frame(var1), aes(x=var1, y=NA, color=groupe)) + geom_point()

#' En $1$ itérations l'algorithme retrouve la partition qui fait le plus "visuellement sens" pour $K=3$ cluster. Mais nous allons voir qu'il est très sensible à l'initialisation.
#' 
#' ### K=3 : mauvaise initialisation
#' Si on initialise mal le kmeans, il tombe dans un minimum local de $W$ ($\iff$ max local de $B$).
## ----echo=F--------------------------------------------------------------
# k =3 différents init
k_moyennes = kmeans(var1, algorithm = 'Lloyd', centers = c(var1[1], var1[2], var1[3]), trace = T)
cat('Le Kmeans à convergé en ', k_moyennes$iter,' itérations. \n')
cat('rapport S/B associé à ', k_moyennes$cluster , ' est : ', k_moyennes$totss / k_moyennes$betweenss, '\n')
groupe = factor(k_moyennes$cluster)
ggplot(data = data.frame(var1), aes(x=var1, y=NA, color=groupe)) + geom_point()

#' 
#' ### Conclusion kmeans
#' En pratique,si on la puissance de calcul nécéssaire, il faire plusieurs kmeans avec différentes initialisation aléatoire des centre. L'argument `nstart`permet de régler ce paramètre. La parition avec le meilleur $B$ est automat séléctionnée.
#' 
#' 
#' # Exercice 6 : Algorithme EM pour les mélanges gaussiens.
#' 
## ------------------------------------------------------------------------
library(mclust)
n = length(var1)
partition1 = factor(c(1.0,1.0,1.0,2.0,2.0,2.0,2.0,2.0,1.0,1.0))
K= length(unique(partition1))
gg = ggplot(data = data.frame(var1), aes(x=var1, y=NA, color=partition1)) + geom_point()
gg

#' 
#' ### Init paramètres
## ------------------------------------------------------------------------
dat = data.frame(var1, partition1=partition1)
compute_group_means = function(x, partition, k) {
  #' Calcul la moyenne dans le groupe k avec la partition courante
  return(mean(x[partition==k]))
}

group_mean = rep(0,K)
for(k in 1:K) {
  group_mean[k] = compute_group_means(var1, partition = partition1, k=k)
}

# alternative : 
group_mean = aggregate(x=var1, by=list(partition1), FUN = function(x) mean(x))
colnames(group_mean) = c("groupe", "mean")
group_mean

#' 
## ------------------------------------------------------------------------
group_var = aggregate(x=var1, by=list(partition1), FUN = function(subset) ((n-1)/n)*var(subset))
colnames(group_var) = c("groupe", "var")
group_var

#' 
## ------------------------------------------------------------------------
csize = table(partition1) / n
csize

#' 
## ------------------------------------------------------------------------
compute_mixture_llhood = function(x, group_mean, group_var, csize) { 
  N = length(x)
  K = length(csize)
  llhood = 0
  for(n in 1:N) {
    temp = 0
    for(k in 1:K) {
      temp = temp + csize[k] * dnorm(x=x[n], mean = group_mean[k], sd = sqrt(group_var[k]))
    }
    llhood = llhood + log(temp)
  }
  return(llhood)
}

cat("Llhood à l\'init : ", compute_mixture_llhood(x=var1, group_mean=group_mean$mean, group_var = group_var$var , csize = csize) , '\n')

#' 
#' ### Begin EM
#' 
#' #### E -step : calcul des $\tau_{ik}$
## ------------------------------------------------------------------------
compute_tau = function(x, group_mean, group_var, csize) {
  N = length(x)
  K = length(csize)
  tau = matrix(0, N, K)
  
  for(n in 1:N) {
    for(k in 1:K) {
      tau[n, k] = csize[k] * dnorm(x=x[n], mean = group_mean[k], sd = sqrt(group_var[k]))
    }
  }
  
  return(tau / rowSums(tau))
}

# cat('Tau : \n')
# tau = compute_tau(x=var1, group_mean=group_mean$mean, group_var = group_var$var , csize = csize) 
# tau

#' 
#' #### M -step 
#' 
#' * __Calcul de $\hat{\pi}$__
## ------------------------------------------------------------------------
csize_Mstep = function(tau) {
  n = dim(tau)[1]
  return(colSums(tau) / n)
}

# csize = csize_Mstep(tau=tau)
# csize

#' 
#' * __Calcul de $\hat{\mu}$__
#' 
## ------------------------------------------------------------------------
mu_Mstep = function(x, tau) {
    N = dim(tau)[1]
    K = dim(tau)[2]
    
    mu = rep(0, K)
    
    for(k in 1:K) {
      norm = 0
      for (i in 1:N) {
        norm = norm + tau[i, k]
        mu[k] = mu[k] + tau[i,k] * x[i]
      }
      mu[k] = mu[k] / norm
    }
    
    return(mu)
}

# mu = mu_Mstep(x = var1, tau = tau)
# mu

#' 
## ------------------------------------------------------------------------
sigma2_Mstep = function(x, tau, mu) {
    N = dim(tau)[1]
    K = dim(tau)[2]
    
    sigma2 = rep(0, K)
    
    for(k in 1:K) {
      norm = 0
      for (i in 1:N) {
        norm = norm + tau[i,k]
        sigma2[k] = sigma2[k] + tau[i,k] * (x[i] - mu[k])^2
      }
      sigma2[k] = sigma2[k] / norm
    }
    
    return(sigma2)
}

# sigma2 = sigma2_Mstep(x=var1, tau = tau, mu = mu )
# print(sigma2)

#' 
#' 
#' 
## ------------------------------------------------------------------------
max.iter = 20
threshold = 1e-6
#init
mu = group_mean$mean
sigma2 = group_var$var
csize = csize
cat("Llhood à l\'init :", compute_mixture_llhood(x=var1, group_mean = mu, group_var = sigma2 , csize = csize) , '\n')

for(ite in 1:max.iter) {
  old = compute_mixture_llhood(x=var1, group_mean = mu, group_var = sigma2 , csize = csize) 
  # E-step
  #TODO 
  tau = compute_tau(x = var1, group_mean = mu, group_var = sigma2, csize = csize)
  
  
  # M-step
  csize = csize_Mstep(tau=tau)
  mu = mu_Mstep(x = var1, tau = tau)
  sigma2 = sigma2_Mstep(x=var1, tau = tau, mu = mu )
  
  new = compute_mixture_llhood(x=var1, group_mean = mu, group_var = sigma2 , csize = csize)
  criterion = abs((new - old)/old)
  if(criterion < threshold) break;
  cat("Llhood à l\'etape ", ite,  " : ", compute_mixture_llhood(x=var1, group_mean = mu, group_var = sigma2 , csize = csize) , '\n')
}
cat('Converged = ', criterion < threshold, '\n')

#' 
#' On peut jouer avec le paramètre `max.iter` et `threshold` pour la convergence de la vraisemblance. Ne pas oublier que l'on converge uniquement vers un maximum **local** de cette dernière. On peut ensuite visualiser les estimateur des paramètre $(\hat{\pi_k}, \hat{\mu_k}, \hat{\Sigma_k})_k$
## ----affichage-params-post-EM--------------------------------------------
for(k in 1:K) {
  cat('----- Cluster ', k, ' ------ \n')
  cat('Pi chapeau : \n')
  print(csize[k])
  cat('mu chapeau \n')
  print(mu[k])
  cat('Sigma chapeau \n')
  print(sigma2[k])
}


#' 
#' 
#' ### Clustering (partitionnement) à la fin de l'EM
#' 
#' On affecte les points selon leurs probabilité à posteriori après convergence de l'algorithme à l'itération $(T)$. Cela revient à estimer $z_i, \forall i$ :
#' 
#' \[ \forall i , \quad \hat{z}_{ik^\star} =1  \textrm{ où : }  k^\star = \arg\max\limits_{k=1,\ldots,K} p(z_{ik} =1 \mid x_i, \theta^{(T)}) = \frac{\pi_k^{(T)}\mathcal{N}(x_i, \mu_k^{(T)}, \Sigma_k^{(T)})}{\sum_l \pi_l^{(T)}\mathcal{N}(x_i, \mu_l^{(T)}, \Sigma_l^{(T)})} \]
#' 
#' En fait cela revient à refaire un $(E)$-step avec $\theta = \theta^{(T)}$, *i.e.* calculer les $\tau_{ik}^{(T+1)}$ et faire un argmax par ligne sur la matrix `tau`.
#' 
## ----predict-clust-------------------------------------------------------
tau = compute_tau(x = var1, group_mean = mu, group_var = sigma2, csize = csize)
clustering = apply(tau, MARGIN = 1, which.max)
cat('Clustering final : ', clustering , '\n')
gg = ggplot(data = data.frame(var1), aes(x=var1, y=NA, color=factor(clustering))) + 
  geom_point() +
  ggtitle('Visualisation du clustering final')
print(gg)

#' 
#' 
#' # EXO A FAIRE :
#' 
#' Relancer la procédure avec $K=3$ en partant d'une partition initiale choisie au hasard ou celle de l'exercice au choix. Quel est l'impact de l'initialisation sur la convergence de l'EM ?
#' 
#' 
#' 
#' 
#' 
#' 
#' 
#' 
#' 
#' 
#' 
#' 
#' 
#' 
#' 
#' 
#' 
#' 
#' 
