library(dplyr)
library(ggplot2)
var1 <- c(-3.3, -4.4, -1.9, 3.3, 2.5, 3.2, 0.3, 0.1, -0.1, -0.5)

library(mclust)
n = length(var1)
partition1 = factor(c(1.0,1.0,1.0,2.0,2.0,2.0,2.0,2.0,1.0,1.0))
K = length(unique(partition1))
ggplot(data = data.frame(var1), aes(x=var1, y=NA, color=partition1)) + geom_point()
dat = data.frame(var1, partition1=partition1)
compute_group_means = function(x, partition, k) {
  #' Calcul la moyenne dans le groupe k avec la partition courante
  return(mean(x[partition==k]))
}

group_mean = rep(0,K)
for(k in 1:K) {
  group_mean[k] = compute_group_means(var1, partition = partition1, k=k)
}

# alternative : 
group_mean = aggregate(x=var1, by=list(partition1), FUN = function(x) mean(x))
colnames(group_mean) = c("groupe", "mean")
group_mean

group_var = aggregate(x=var1, by=list(partition1), FUN = function(subset) ((n-1)/n)*var(subset))
colnames(group_var) = c("groupe", "var")
group_var
csize = table(partition1) / n
csize