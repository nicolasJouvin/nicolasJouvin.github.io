

# Etape E : considère theta(t) fixé et je calcul 
# p(z_i | x_i, \theta(t)) -> log(tau_{ik}) = log(\pi_k) +  log N(y_i; \theta(t)) + Cte
# Ep[z_{ik}] = tau_{ik}
compute_tau = function(X, theta, K) {
  n = length(X)
  logtau = matrix(data = 0, nrow = n, ncol = K) 
  for (i in 1:n) {
    for (k in 1:K) {
      logtau[i,k] = log(theta$PI[k]) + dnorm(X[i], mean = theta$mu[k], sd = sqrt(theta$sigma2[k]), 
                                             log = TRUE) 
    }
  }
  tau = exp(logtau) # tau non normalisé
  tau = tau / rowSums(tau) # tau[i,] normalisés pour être des probas
  return(tau)
}


# Etape M

updatePI = function(tau) {
  n = nrow(tau)
  return(colSums(tau) / n)
}

updateMu = function(X, tau) {
  K = ncol(tau)
  mu = rep(0, K)
  for (k in 1:K) {
    mu[k] = sum(tau[,k] * X) / sum(tau[,k])
  }
  
  return(mu)
}

updateSigma = function(X, tau, mu) {
  K = ncol(tau)
  sigma = rep(0, K)
  for (k in 1:K) {
    sigma[k] = sum(tau[,k] * (var1 - mu[k])^2) / sum(tau[,k])
  }
  
  return(sigma)
}

Mstep = function(X, tau) {
  theta = list()
  theta$PI = updatePI(tau)
  theta$mu = updateMu(X, tau)
  theta$sigma2 = updateSigma(X, tau, mu = theta$mu)
  
  return(theta)
}

# calcul log vraisemblance

compute_llhood = function(X, theta) {
  res = 0
  for (i in 1:n) {
    temp = 0
    for (k in 1:K) {
      temp = temp + theta$PI[k] * dnorm(X[i], mean = theta$mu[k], 
                                        sd = sqrt(theta$sigma2[k]), log = F)
    }
    res = res + log(temp)
  }
  
  return(res)
}