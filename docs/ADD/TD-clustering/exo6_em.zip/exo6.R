source('./EM_dim1.R')

var1 <- c(-3.3, -4.4, -1.9, 3.3, 2.5, 3.2, 0.3, 0.1, -0.1, -0.5)
n = length(var1)
partition1 = factor(c(1.0,1.0,1.0,2.0,2.0,2.0,2.0,2.0,1.0,1.0))
partition1 = factor(c(1.0,3.0,2.0,1.0,3.0,2.0,1.0,3.0,2.0,1.0))

K = length(unique(partition1))
gg = ggplot(data = data.frame(var1), aes(x=var1, y=NA, color=partition1)) + geom_point()
gg

K

theta = list()
theta$PI = rep(0, K)
theta$mu = rep(0, K)
theta$sigma2 = rep(0, K) 

#initialisation à l'aide de partition 1
theta$PI = table(partition1) / n
for (k in 1:K) {
  theta$mu[k] = mean(var1[partition1 == k])
  theta$sigma2[k] = ((n - 1)/n) * var(var1[partition1 == k])
}

theta
# vraisemblance à l'initialisation (avant l'EM)
llhood0 = compute_llhood(X = var1, theta = theta)

# 1 itération de EM
count = 0
max.iter = 100
atol = 1e-6
llhood = compute_llhood(X = var1, theta = theta)
logliks = c(llhood)
conv = Inf
while (count < max.iter & conv > atol) {
  prev_llhood = llhood
  count = count + 1
  
  #EM
  tau = compute_tau(X = var1, theta = theta, K = K)
  theta = Mstep(var1, tau)
  
  llhood = compute_llhood(X = var1, theta = theta)
  logliks = c(logliks, llhood)
  conv = abs((llhood - prev_llhood)/prev_llhood)
}
print(count)
plot(logliks)

cl = as.factor(apply(tau, 1, which.max))
  
gg2 = ggplot(data = data.frame(var1), aes(x=var1, y=NA, color=cl)) + geom_point()
gg2
