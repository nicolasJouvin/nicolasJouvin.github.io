#' ---
#' title: "TD/TP 2 d'analyse de données - M1 MAEF"
#' author: Nicolas jouvin
#' output: html_notebook
#' ---
#' 
#' <!-- # Installation du package `dplyr`  -->
#' 
#' <!-- ```{r, warning=FALSE} -->
#' <!-- #commande à lancer si pas installé : install.packages('dplyr') -->
#' <!-- library(dplyr) -->
#' <!-- ``` -->
#' 
#' # Exercice 1
#' 
#' ###  Création des données 
#' On a deux échantillons de 10 individus pour lesquelles on observe une variable. On souhaite effectuer des résumés et test statistiques sur ceux ci (visualisation de la distribution empirique, test de Student, etc.) On va les stocker dans une data-frame et laisser R faire le travail. Il est à noter que la plupart du temps les data-frames sont utilisées pour étudier des tableaux individus variable
#' 
## ------------------------------------------------------------------------
ech1<-c(3.7, 5.2, 5.0, 1.2, 7.9, 5.3, 6.8, 4.6, 2.5, 3.4)
ech2<-c(5.8, 5.5, 5.3, 5.9, 4.9, 3.1, 6.6, 1.4, 3.6, 2.6)
donnees = data.frame(ech1, ech2)
donnees

#' 
#' ###Q1. Boxplots
#' 
#' La commande `boxplot` de R permet de tracer les boîtes à moustaches. Appliqué à une data frame elle va créer un graphique avec les boxplot de chaque variable.
## ------------------------------------------------------------------------
boxplot(donnees)

#' Les distributions ont à peu près le même support mais la distribution du premier échantillon semble plus étalée et "symmétrique"" par rapport à celle du second.
#' 
#' ## Q2. Test de student avec $\mu_0 = 5$
#' La fonction `t.test` permet d'effectuer un test de student sur un vecteur de taille $n$. On peut stocker son résultat dans une variable et afficher celle-ci, l'affichage est conçu pour être lisible (la fonction `print` de l'objet test à été réécrite pour que R le formate de manière agréable).
## ------------------------------------------------------------------------
?t.test # la doc explique le rôle des arguments.
mu0 = 5 # on peut s'amuser à changer
test1 = t.test(donnees$ech1, mu = mu0, alternative = 'two.sided', conf.level = 0.95)
print(test1)

#' Toutes les informations pertinentes du test sont affichées et on ne peut rejeter pas rejeter $H_0$ au seuil de $5\%$. A noter que cela ne veut **absolument pas** dire que $H_0$ est vraie à $95\%$. La p-value nous dit que l'on pourrait rejeter $H_0$ alors qu'elle est vraie avec un risque minimum `r test1$p.value`$\%$. De la même manière, cela ne veut **absolument pas** dire que $H_0$ est vraie à `r test1$p.value`$\%$.
#' 
#' 
#' Si on veut accéder à des valeurs précises de la variable `test1` (la valeur de la statistique de test ou bien le la p-valeur) on peut y accéder avec l'opérateur $ (c'est l'opérateur spécifique aux listes en R, les data frames sont donc des listes mais avec d'autres propriétés plus pratiques que les listes de base) .
## ------------------------------------------------------------------------
print(paste0('La valeur de la statistique de test est t=', test1$statistic))
print(paste0('La p-value de ce test est : p=', test1$p.value))

#' 
#' On peut par exemple vérifier que le calcul la valeur de $t$ 
#' \[
#' t = \sqrt{n} \frac{(\bar{X}_n - \mu_o)}{\hat{S}_n} \quad \textrm{où : } \hat{S}_n = \frac{1}{n-1}\sum_{i=1}^n (X_i - \bar{X}_n)^2
#' \]
#' 
## ------------------------------------------------------------------------
n = length(donnees$ech1)
t_test =  (mean(donnees$ech1) - mu0) / sqrt(var(donnees$ech1)/n) # /!\ var() renvoi bien l'estimateur non biaisé de sigma
print(t_test)
print((t_test == test1$statistic)) 

#' 
#' Pour l'échantillon 2 nous obtenons le test
## ------------------------------------------------------------------------
test2 = t.test(donnees$ech2, mu = mu0, alternative = 'two.sided', conf.level = 0.95)
print(test2)

#' De la même manière nous ne pouvons **pas** rejeter $H_0$ avec une confiance de $95\%$.
#' 
#' ### Q3. Boxplot et loi normale
#' 
#' Cf. exo 2
#' 
#' 
#' # Exercice 2
#' 
#' On travaille avec les mêmes données.
#' 
#' ### Q1. Statistiques usuelles
#' 
## ------------------------------------------------------------------------
summary(donnees$ech1)
summary(donnees$ech2)

#' 
## ------------------------------------------------------------------------
?quantile
quantile(ech1, type=4)
quantile(ech1, type=5) 

#' 
#' ### Q2. qqplot et "test" (visuel) de normalité
## ------------------------------------------------------------------------
qqnorm((ech1 - mean(ech1))/sd(ech1), xlim = c(-1.5, 1.5) , ylim =c(-1.5, 1.5)  )
abline(0,1, col='red')
qqnorm((ech2 - mean(ech2))/sd(ech2),  xlim = c(-1.5, 1.5) , ylim =c(-1.5, 1.5) )
abline(0,1, col='red')

#' 
#' ###Q3. qqplot des 2 distributions
## ------------------------------------------------------------------------
qqplot( (donnees$ech1 - mean(donnees$ech1) )/ sd(donnees$ech1), (donnees$ech2 - mean(donnees$ech2) )/ sd(donnees$ech2), xlim = c(-3, 3) , ylim =c(-3, 3) , xlab = 'ech1 centré réduit', ylab = 'ech2 centré réduit')
abline(0,1, col='red')

#' 
#' 
#' # Exercice 3
#' Le jeu de données des Iris de Fisher est l'exemple jouet par excellence des débutants de R.
## ------------------------------------------------------------------------
data(iris) # charge une data frame nommées `iris` dans le workspace

#' 
#' ### 3.1 Résumés numériques
#' 
#' Déjà vu en TP
#' 
#' ### 3.2 Histogramme et estimation de densité
#' 
## ------------------------------------------------------------------------
hist(iris$Sepal.Length)
stem(iris$Sepal.Length)

#' 
## ------------------------------------------------------------------------
hist(iris[, 1], probability = T)
hist(iris[, 1], probability = T, breaks = seq(3,9, length.out = 10))

#?density
d1 <- density(iris[,1], kernel = 'gaussian')
d2 <- density(iris[,1], kernel = 'rectangular')
lines(d1, col="red")
lines(d2, col="green")
legend(x = 'topright', col = c('red', 'green'), legend = c('Noyau gaussien', 'Noyau rectangulaire'), lty = c(1, 1))

#' 
#' Estimation d'une densité 2-D 
#' 
## ------------------------------------------------------------------------
library(MASS)
d_2d <- kde2d(iris[,1],iris[,2])
image(d_2d)
#essayer: contour(d_2d)

#' 
#' L'intérêt d'une telle visualisation est qu'elle nous permet de visualiser la 3ème dimension sur un graphique à 2 dimensions via l'échelle des couleurs. En effet nous ne disposon pas encore d'hologramme pour réellement projeter en 3D et les plots "3D" actuels présentent souvent un problème de perspective. La visualisation se fait uniquement à 2 ou 3 dimensions, si des observations sont multivariées en dimension $d > 3$ des méthodes de *réduction de dimension* sont alors souvent utilisées pour la visualisation. Nous verrons l'ACP en TD. 
