library(FactoMineR)

# Exemple 1
eleves <- read.table("./eleves.txt", header=T)
eleves.pca <- PCA(eleves, scale.unit=T, ncp=4, axes= c(1,2))
eleves.pca
eleves.pca$eig
eleves.pca$var
eleves.pca$ind
eleves.pca$call
plot(eleves.pca, axes=c(2,3),choix="ind")

# Exemple 2
iris[1:10,]
iris.pca <- PCA(iris,scale.unit=T, ncp=4, quali.sup=5)
iris.pca$eig
iris.pca$var
iris.pca$ind
plot(iris.pca,axes=c(1,3),choix="ind", habillage=5)

# Exemple 3
library(FactoMineR)
data(decathlon)
?decathlon

ncp = 12
decathlon.pca = PCA(decathlon, scale.unit=T, ncp=ncp, quali.sup=13)
plot(1:ncp, decathlon.pca2$eig[,3])

decathlon.pca$eig
decathlon.pca$var
decathlon.pca$ind

plot(decathlon.pca, choix = "var")
# exploration des athlètes dans le plan factoriel : 
plot(decathlon.pca, choix = "ind", axes=c(1,2), habillage = 13)


# en excluant le rang et les points "à la main"
X = decathlon[, -c(11,12)]
decathlon.pca2 = PCA(X, scale.unit=T, ncp=10, quali.sup=11)
decathlon.pca2$eig
plot(decathlon.pca2, choix = "var")

# en excluant le rang et les points avec FactoMineR : elles n'influencent
# pas la construction des axes mais sont tracées sur le cercle des corrélations pour 
# aider à la compréhension des axes.
decathlon.pca3 = PCA(decathlon, scale.unit=T, ncp=10, quanti.sup = 11:12, quali.sup=13)
decathlon.pca3$eig
plot(decathlon.pca3, choix = "var")
plot(decathlon.pca3, choix = "ind", axes=c(1,2), habillage = 13)



# Exemple 4
library(cluster)
?votes.repub

# Exemple 5
library(datasets)
?airquality






